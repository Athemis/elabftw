﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'sl', {
	ltr: 'Smer besedila od leve proti desni',
	rtl: 'Smer besedila od desne proti levi'
} );
