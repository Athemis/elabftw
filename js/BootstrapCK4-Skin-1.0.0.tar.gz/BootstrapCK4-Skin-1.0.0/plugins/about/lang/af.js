﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'af', {
	copy: 'Kopiereg &copy; $1. Alle regte voorbehou.',
	dlgTitle: 'Info oor CKEditor',
	help: 'Check $1 for help.', // MISSING
	moreInfo: 'Vir lisensie-informasie, besoek asb. ons webwerf:',
	title: 'Info oor CKEditor',
	userGuide: 'CKEditor User\'s Guide'
} );
